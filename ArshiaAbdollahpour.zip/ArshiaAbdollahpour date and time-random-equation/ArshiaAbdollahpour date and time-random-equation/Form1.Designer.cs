﻿namespace ArshamRezakhani_date_and_time_random_equation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timeLabel = new System.Windows.Forms.Label();
            this.textBoxA = new System.Windows.Forms.TextBox();
            this.textBoxB = new System.Windows.Forms.TextBox();
            this.textBoxC = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rootLabel1 = new System.Windows.Forms.Label();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.rootLabel2 = new System.Windows.Forms.Label();
            this.random2TBMinValue = new System.Windows.Forms.TextBox();
            this.random2TBMaxValue = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.random2ComboBox = new System.Windows.Forms.ComboBox();
            this.random2Btn = new System.Windows.Forms.Button();
            this.random2Answer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Location = new System.Drawing.Point(37, 20);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(77, 13);
            this.timeLabel.TabIndex = 0;
            this.timeLabel.Text = "Date and Time";
            // 
            // textBoxA
            // 
            this.textBoxA.Location = new System.Drawing.Point(40, 155);
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.Size = new System.Drawing.Size(32, 20);
            this.textBoxA.TabIndex = 1;
            // 
            // textBoxB
            // 
            this.textBoxB.Location = new System.Drawing.Point(110, 155);
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.Size = new System.Drawing.Size(31, 20);
            this.textBoxB.TabIndex = 2;
            // 
            // textBoxC
            // 
            this.textBoxC.Location = new System.Drawing.Point(167, 155);
            this.textBoxC.Name = "textBoxC";
            this.textBoxC.Size = new System.Drawing.Size(27, 20);
            this.textBoxC.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(147, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "X +";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "X^2 +";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(200, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "=";
            // 
            // rootLabel1
            // 
            this.rootLabel1.AutoSize = true;
            this.rootLabel1.Location = new System.Drawing.Point(225, 145);
            this.rootLabel1.Name = "rootLabel1";
            this.rootLabel1.Size = new System.Drawing.Size(39, 13);
            this.rootLabel1.TabIndex = 7;
            this.rootLabel1.Text = "Root 1";
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(110, 198);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(75, 23);
            this.calculateBtn.TabIndex = 8;
            this.calculateBtn.Text = "Calculate ";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // rootLabel2
            // 
            this.rootLabel2.AutoSize = true;
            this.rootLabel2.Location = new System.Drawing.Point(225, 175);
            this.rootLabel2.Name = "rootLabel2";
            this.rootLabel2.Size = new System.Drawing.Size(39, 13);
            this.rootLabel2.TabIndex = 9;
            this.rootLabel2.Text = "Root 2";
            // 
            // random2TBMinValue
            // 
            this.random2TBMinValue.Location = new System.Drawing.Point(505, 153);
            this.random2TBMinValue.Name = "random2TBMinValue";
            this.random2TBMinValue.Size = new System.Drawing.Size(100, 20);
            this.random2TBMinValue.TabIndex = 10;
            // 
            // random2TBMaxValue
            // 
            this.random2TBMaxValue.Location = new System.Drawing.Point(622, 153);
            this.random2TBMaxValue.Name = "random2TBMaxValue";
            this.random2TBMaxValue.Size = new System.Drawing.Size(100, 20);
            this.random2TBMaxValue.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(369, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(466, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Please Enter your range of numbers for Random 2 Next Method :";
            // 
            // random2ComboBox
            // 
            this.random2ComboBox.FormattingEnabled = true;
            this.random2ComboBox.Items.AddRange(new object[] {
            "Next",
            "NextDouble"});
            this.random2ComboBox.Location = new System.Drawing.Point(394, 152);
            this.random2ComboBox.Name = "random2ComboBox";
            this.random2ComboBox.Size = new System.Drawing.Size(74, 21);
            this.random2ComboBox.TabIndex = 13;
            // 
            // random2Btn
            // 
            this.random2Btn.Location = new System.Drawing.Point(536, 251);
            this.random2Btn.Name = "random2Btn";
            this.random2Btn.Size = new System.Drawing.Size(119, 23);
            this.random2Btn.TabIndex = 14;
            this.random2Btn.Text = "Use the Method";
            this.random2Btn.UseVisualStyleBackColor = true;
            this.random2Btn.Click += new System.EventHandler(this.random2Btn_Click);
            // 
            // random2Answer
            // 
            this.random2Answer.AutoSize = true;
            this.random2Answer.Location = new System.Drawing.Point(574, 208);
            this.random2Answer.Name = "random2Answer";
            this.random2Answer.Size = new System.Drawing.Size(81, 13);
            this.random2Answer.TabIndex = 15;
            this.random2Answer.Text = "Method Answer";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(872, 492);
            this.Controls.Add(this.random2Answer);
            this.Controls.Add(this.random2Btn);
            this.Controls.Add(this.random2ComboBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.random2TBMaxValue);
            this.Controls.Add(this.random2TBMinValue);
            this.Controls.Add(this.rootLabel2);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.rootLabel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxC);
            this.Controls.Add(this.textBoxB);
            this.Controls.Add(this.textBoxA);
            this.Controls.Add(this.timeLabel);
            this.Name = "Form1";
            this.Text = "Ostad amani Project";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.TextBox textBoxA;
        private System.Windows.Forms.TextBox textBoxB;
        private System.Windows.Forms.TextBox textBoxC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label rootLabel1;
        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.Label rootLabel2;
        private System.Windows.Forms.TextBox random2TBMinValue;
        private System.Windows.Forms.TextBox random2TBMaxValue;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox random2ComboBox;
        private System.Windows.Forms.Button random2Btn;
        private System.Windows.Forms.Label random2Answer;
    }
}

