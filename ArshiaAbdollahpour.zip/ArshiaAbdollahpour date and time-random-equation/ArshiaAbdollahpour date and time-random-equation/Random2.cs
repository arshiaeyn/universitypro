﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArshamRezakhani_date_and_time_random_equation
{
    public class Random2
    {
        private int seed;

        public Random2()
        {
            seed = (int)DateTime.Now.Ticks;
        }

        public int Next(int maxValue)
        {
            return Next(0, maxValue);
        }

        public int Next(int minValue, int maxValue)
        {

            if (minValue >= maxValue)
                throw new ArgumentException("minValue must be less than maxValue.");


            seed = (seed * 1664525 + 1013904223) % int.MaxValue;
            int randomValue = minValue + Math.Abs(seed) % (maxValue - minValue);
            return randomValue;

        }

        public double NextDouble()
        {

            return (double)Next(0, 100) / 100.0;
        }
    }


}
