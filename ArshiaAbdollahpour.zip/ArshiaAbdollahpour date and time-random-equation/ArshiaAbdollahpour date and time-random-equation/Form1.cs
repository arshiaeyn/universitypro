﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



//Arsham Rezakhani

namespace ArshamRezakhani_date_and_time_random_equation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            this.timeLabel.Text = time.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void calculateBtn_Click(object sender, EventArgs e)
        {
            double a = double.Parse(this.textBoxA.Text);
            double b = double.Parse(this.textBoxB.Text);
            double c = double.Parse(this.textBoxC.Text);

            if (string.IsNullOrWhiteSpace(textBoxA.Text) || string.IsNullOrWhiteSpace(textBoxB.Text) || string.IsNullOrWhiteSpace(textBoxC.Text))
            {
                MessageBox.Show("Please fill the TextBoxes Properly !","Alert",MessageBoxButtons.OK);
            }
            else
            {
                double discriminant = b * b - 4 * a * c;
                if (discriminant >= 0)
                {
                    double root1 = (-b + Math.Sqrt(discriminant)) / (2 * a);
                    double root2 = (-b - Math.Sqrt(discriminant)) / (2 * a);

                    rootLabel1.Text = root1.ToString();
                    rootLabel2.Text = root2.ToString();
                    
                }
                else
                {
                    MessageBox.Show("No real roots exist.","alert", MessageBoxButtons.OK);
                }
            }
        }

        private void random2Btn_Click(object sender, EventArgs e)
        {
            Random2 randomNum = new Random2();

            switch (random2ComboBox.Text)
            {
                case "Next":

                    if (string.IsNullOrEmpty(random2TBMinValue.Text) && string.IsNullOrEmpty(random2TBMaxValue.Text))
                    {
                        MessageBox.Show("Please fill the TextBoxes Properly !", "Alert", MessageBoxButtons.OK);
                    }
                    else if (string.IsNullOrEmpty(random2TBMinValue.Text) && !string.IsNullOrEmpty(random2TBMaxValue.Text))
                    {
                        random2Answer.Text = randomNum.Next(int.Parse(random2TBMaxValue.Text)).ToString();
                    }
                    else if (string.IsNullOrEmpty(random2TBMaxValue.Text) && !string.IsNullOrEmpty(random2TBMinValue.Text))
                    {
                        random2Answer.Text = randomNum.Next(int.Parse(random2TBMinValue.Text)).ToString();
                    }
                    else if (!string.IsNullOrEmpty(random2TBMaxValue.Text) && !string.IsNullOrEmpty(random2TBMinValue.Text))
                    {
                        if (int.Parse(random2TBMinValue.Text) < int.Parse(random2TBMaxValue.Text))
                        {
                            random2Answer.Text = randomNum.Next(int.Parse(random2TBMinValue.Text), int.Parse(random2TBMaxValue.Text)).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Min Value should be less than Max value please correct it !", "Alert", MessageBoxButtons.OK);
                        }
                    }
                    
                    break;

                case "NextDouble":
                     random2Answer.Text =  randomNum.NextDouble().ToString();
                    break;
                default:
                    break;
            }

            
        }
    }
}
